# Design: Tashkent bike network

Paper design, written before the code. No code in this file.

## 1. Noun sorting

Every noun of the requirement text, with the decision rule applied.

| Noun in the text | Has data **and** behaviour? | Decision | Why |
|---|---|---|---|
| network | yes (knows stations, runs rides) | **class `Network`** | coordinates take / return |
| station | yes (name, docks; parks and gives bikes) | **class `Station`** | |
| dock | yes (holds ≤ 1 bike; refuses a second one) | **class `Dock`** | |
| bike | yes (status; allowed status changes) | **class `Bike`** | |
| rider / user | yes (name, active ride; at most one) | **class `Rider`** | "rider" and "user" are two names for one thing → **merged**, the code says `Rider` |
| ride | yes (start/end station, times, fee) | **class `Ride`** | event with data, the "noun you cannot touch" |
| fee | no, a value computed from a ride | method `Ride.fee()` | owns the money rule |
| start station, end station | no, just links of a ride | attributes of `Ride` | |
| start time, end time | no, values | attributes of `Ride` | |
| number of docks | no, a value | `Station.capacity` | |
| status (available / in use / repair) | no, a value | `BikeStatus` enum, attribute of `Bike` | |
| free docks | no, derived | property `Station.free_docks` | |
| sum (money) | no, a value | `int` | whole sum, no floats |
| repair | no, a state | `BikeStatus.REPAIR` | |
| manager | outside the program | **actor** | uses `Network.report()` |
| rider (the human) | outside the program | **actor** | taps "Take" / "Return" |
| app | outside the program | **actor / UI** | only calls `Network` |
| receipt | text made from a ride | class `ReceiptPrinter` (helper) | not in the requirement text; added because the task asks `ReceiptPrinter.print(ride)` |

Result: **6 classes from the requirement** (`Network`, `Station`, `Dock`, `Bike`, `Rider`, `Ride`) plus the helper `ReceiptPrinter`.

### Vague words → questions for the customer

| Vague word | Question |
|---|---|
| "any station" | Can a rider return the bike to the station where it was taken? (we assume yes) |
| "free" | A free *dock* is empty; a free *bike* is AVAILABLE. Is a bike in REPAIR counted as "bike" in the station's bike count? (we assume yes: it is physically docked) |
| "sent to repair" | Who sends it (manager? mechanic?) and how does it come back? (we added `finish_repair`) |
| "first 15 minutes are free" | Is exactly 15:00 free? (we assume yes: 15:00 → 0, 15:01 → 500) |
| "times" | Which time zone, and who provides the clock? (the caller passes time in; classes never read the clock) |
| "manager sees" | On which screen, how often refreshed? (we assume a console report on demand) |
| "full station" on return | If no station has a free dock, where is the rider sent? (the error carries no redirect) |

## 2. Event with data: the money rule

`Ride` is the event. **`Ride.fee()`** owns the money rule. The numbers 15, 5, 500 and 20 000
are constants in `bikenet/ride.py` and are written nowhere else (a test checks this).

## 3. CRC cards

| Class | Responsibilities | Collaborators |
|---|---|---|
| **Bike** | 1. know its id<br>2. know its status (read-only)<br>3. change status only by allowed moves (docked, taken, repair, repaired) | Dock |
| **Dock** | 1. hold at most one bike<br>2. park a bike, refuse if occupied<br>3. hand a bike out only if AVAILABLE<br>4. send its bike to repair / back | Bike |
| **Station** | 1. own its docks (created inside, read-only tuple)<br>2. park a returned bike in a free dock, else say "full"<br>3. give out a free bike<br>4. show free docks, `str`, `len`, ordering | Dock, Bike |
| **Ride** | 1. know rider, bike, start/end station, times<br>2. check and set the end (end ≥ start)<br>3. **calculate the fee**<br>4. count failed returns of this ride | Rider, Bike, Station |
| **Rider** | 1. know its name<br>2. know its active ride (at most one) | Ride |
| **Network** | 1. know its stations<br>2. run "Take" (checks, new ride)<br>3. run "Return" (failure, redirect, closing)<br>4. keep the ride history and the manager report | Station, Rider, Ride, ReceiptPrinter |
| **ReceiptPrinter** | 1. format a finished ride as one line<br>2. print it | Ride |

No card has more than 4 responsibilities, so no class was split.

## 4. Scenario read aloud: "rider returns bike to a full station"

| # | Step | Owner card |
|---|---|---|
| 1 | Rider taps "Return" at Yunusobod | actor → **Network** |
| 2 | Find the rider's active ride (none → `NoActiveRideError`) | **Rider** |
| 3 | Check that the return time is not before the start | **Ride** |
| 4 | Ask the station to park the bike | **Station** |
| 5 | Station looks for a free dock, finds none, says "full" | **Station** (`StationFullError`) |
| 6 | Count this failure for this ride | **Ride** (see round log) |
| 7 | Decide the redirect after the 2nd failure: most free docks, tie → name A–Z | **Network** (it knows all stations) |
| 8 | Error is raised and carries the redirect | `StationFullError` (exception, carries data) |
| 9 | The ride clock keeps running (the ride has no end yet) | **Ride** |
| 10 | Retry at the redirect: park, finish ride, close it for the rider, charge, print | **Station**, **Ride**, **Rider**, **ReceiptPrinter** |

### Round log (steps without an owner)

* **Round 1:** step 6 (count failures) had no card. First idea: `Network` keeps a dictionary *ride → count*.
  Problem: that is data *about a ride* stored far from the ride, and it must be cleaned up when the ride ends.
* **Round 2:** moved the responsibility to `Ride`. Now nothing has to be cleaned up and the counter is born and dies with the ride.
* The owner was found inside 2 rounds. **Why `Ride` (Information Expert):** `Ride` already holds
  the data the counter belongs to (the ride itself); the failure count describes only that ride.
