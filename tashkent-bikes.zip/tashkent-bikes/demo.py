"""Console demo (about 3 seconds). Same scenario as the video in README.md.

Run:  python demo.py
Times are passed in as parameters, so the output is the same on every run.
"""
from datetime import datetime, timedelta

from bikenet import Bike, Network, Rider, Station, StationFullError

T0 = datetime(2026, 11, 10, 9, 0)


def at(minutes: int) -> datetime:
    return T0 + timedelta(minutes=minutes)


def stocked(name: str, capacity: int, bikes: int) -> Station:
    station = Station(name, capacity)
    for n in range(bikes):
        station.park_bike(Bike(f"{name[0]}-{n + 1}"))
    return station


def title(text: str) -> None:
    print(f"\n=== {text} ===")


chilonzor = stocked("Chilonzor", 4, 4)
yunusobod = stocked("Yunusobod", 2, 1)
mirobod = stocked("Mirobod", 4, 1)
sergeli = stocked("Sergeli", 3, 0)
network = Network([chilonzor, yunusobod, mirobod, sergeli])

title("START: manager view")
network.report()

title("1. HAPPY PATH: Ali takes a bike and returns it to a free dock")
ali = Rider("Ali")
network.take_bike(ali, chilonzor, at(0))
print(f"Ali took a bike at {chilonzor}")
network.return_bike(ali, yunusobod, at(23))   # prints the receipt
print(f"Yunusobod is now: {yunusobod}")

title("2. FAILURE PATH: Vali returns to the full Yunusobod, twice")
vali = Rider("Vali")
network.take_bike(vali, chilonzor, at(60))
redirect = None
for attempt, minute in enumerate((65, 67), start=1):
    try:
        network.return_bike(vali, yunusobod, at(minute))
    except StationFullError as error:
        print(f"attempt {attempt}: {error}")
        redirect = error.redirect
print(f"Ride still running: {vali.active_ride}")

title("3. RECOVERY PATH: Vali returns to the redirected station")
network.return_bike(vali, redirect, at(81))   # prints the receipt

title("4. OPTIONAL: repair and manager report")
network.send_to_repair(chilonzor, 3)
print("Chilonzor dock 3 bike sent to repair, it stays in the dock:")
print(f"  {chilonzor}")
network.report()
