from datetime import datetime, timedelta

import pytest

from bikenet import (Bike, BikeStatus, Network, NoActiveRideError, NoBikeError,
                     Rider, RideActiveError, Station, StationFullError)

T0 = datetime(2026, 11, 10, 9, 0, 0)


def minutes(n):
    return T0 + timedelta(minutes=n)


def stocked(name, capacity, bikes):
    station = Station(name, capacity)
    for n in range(bikes):
        station.park_bike(Bike(f"{name[0]}-{n + 1}"))
    return station


@pytest.fixture
def world():
    chilonzor = stocked("Chilonzor", 5, 4)
    yunusobod = stocked("Yunusobod", 2, 2)   # full
    mirobod = stocked("Mirobod", 4, 1)       # 3 free
    sergeli = stocked("Sergeli", 3, 0)       # 3 free -> tie with Mirobod
    net = Network([chilonzor, yunusobod, mirobod, sergeli])
    return net, chilonzor, yunusobod, mirobod, sergeli


def places_of(net, bike):
    """In how many docks is this bike? (rides are counted by the caller)"""
    return sum(1 for s in net.stations for d in s.docks if d.bike is bike)


def test_if_rider_has_no_active_ride_and_station_has_a_free_bike_new_ride_starts(world):
    net, chilonzor, *_ = world
    ali = Rider("Ali")
    ride = net.take_bike(ali, chilonzor, T0)
    assert ali.active_ride is ride
    assert ride.bike.status is BikeStatus.IN_USE
    assert len(chilonzor) == 3


def test_if_rider_already_has_an_active_ride_ride_active_error(world):
    net, chilonzor, *_ = world
    ali = Rider("Ali")
    net.take_bike(ali, chilonzor, T0)
    with pytest.raises(RideActiveError):
        net.take_bike(ali, chilonzor, minutes(1))
    assert len(chilonzor) == 3  # the second bike stayed docked


def test_if_station_has_no_free_bike_no_bike_error(world):
    net, *_, sergeli = world
    with pytest.raises(NoBikeError):
        net.take_bike(Rider("Ali"), sergeli, T0)


def test_if_the_only_bike_is_in_repair_no_bike_error():
    station = stocked("A", 2, 1)
    net = Network([station])
    net.send_to_repair(station, 1)
    with pytest.raises(NoBikeError):
        net.take_bike(Rider("Ali"), station, T0)


def test_if_return_without_a_ride_no_active_ride_error(world):
    net, chilonzor, *_ = world
    with pytest.raises(NoActiveRideError):
        net.return_bike(Rider("Ali"), chilonzor, T0)


def test_if_rider_returns_bike_to_a_free_dock_ride_is_closed_fee_charged_receipt_printed(world, capsys):
    net, chilonzor, yunusobod, mirobod, _ = world
    ali = Rider("Ali")
    net.take_bike(ali, chilonzor, T0)
    ride = net.return_bike(ali, mirobod, minutes(23))
    assert ali.active_ride is None
    assert ride.fee() == 1_000
    assert "Chilonzor → Mirobod, 23 min, 1 000 sum" in capsys.readouterr().out


def test_if_station_is_full_on_return_station_full_error_and_ride_keeps_running(world):
    net, chilonzor, yunusobod, *_ = world
    ali = Rider("Ali")
    ride = net.take_bike(ali, chilonzor, T0)
    with pytest.raises(StationFullError) as info:
        net.return_bike(ali, yunusobod, minutes(5))
    assert info.value.redirect is None          # first failure: no redirect yet
    assert ali.active_ride is ride and not ride.is_finished
    assert ride.bike.status is BikeStatus.IN_USE


def test_if_rider_tries_again_after_a_failed_return_it_can_succeed(world):
    net, chilonzor, yunusobod, mirobod, _ = world
    ali = Rider("Ali")
    net.take_bike(ali, chilonzor, T0)
    with pytest.raises(StationFullError):
        net.return_bike(ali, yunusobod, minutes(5))
    ride = net.return_bike(ali, mirobod, minutes(10))
    assert ride.is_finished


def test_if_the_same_ride_fails_n_2_times_error_carries_redirect_most_free_docks_tie_a_to_z(world):
    net, chilonzor, yunusobod, mirobod, sergeli = world
    ali = Rider("Ali")
    ride = net.take_bike(ali, chilonzor, T0)
    with pytest.raises(StationFullError):
        net.return_bike(ali, yunusobod, minutes(5))
    with pytest.raises(StationFullError) as info:
        net.return_bike(ali, yunusobod, minutes(7))
    assert mirobod.free_docks == sergeli.free_docks == 3  # tie
    assert info.value.redirect is mirobod                  # Mirobod < Sergeli (A-Z)
    assert ride.failed_returns == 2                        # the counter lives in Ride


def test_if_rider_returns_bike_to_the_redirected_station_ride_is_closed_fee_charged_receipt_printed(world, capsys):
    net, chilonzor, yunusobod, *_ = world
    ali = Rider("Ali")
    net.take_bike(ali, chilonzor, T0)
    for when in (5, 7):
        with pytest.raises(StationFullError) as info:
            net.return_bike(ali, yunusobod, minutes(when))
    ride = net.return_bike(ali, info.value.redirect, minutes(21))
    assert ride.is_finished and ali.active_ride is None
    assert ride.fee() == 1_000
    assert "Chilonzor → Mirobod, 21 min, 1 000 sum" in capsys.readouterr().out


def test_if_every_station_is_full_redirect_is_none():
    a, b = stocked("A", 1, 1), stocked("B", 1, 1)
    c = stocked("C", 2, 1)
    net = Network([a, b, c])
    ali = Rider("Ali")
    net.take_bike(ali, c, T0)          # C is empty now ...
    c.park_bike(Bike("X"))             # ... then someone else fills it
    c.park_bike(Bike("Y"))
    for _ in range(2):
        with pytest.raises(StationFullError) as info:
            net.return_bike(ali, a, minutes(3))
    assert info.value.redirect is None


def test_if_a_ride_is_finished_it_records_start_and_end_station_and_times(world):
    net, chilonzor, _, mirobod, _ = world
    ali = Rider("Ali")
    net.take_bike(ali, chilonzor, T0)
    net.return_bike(ali, mirobod, minutes(10))
    (ride,) = net.rides
    assert (ride.start_station, ride.end_station) == (chilonzor, mirobod)
    assert (ride.start_time, ride.end_time) == (T0, minutes(10))


def test_if_return_time_is_before_start_value_error_and_bike_is_not_moved(world):
    net, chilonzor, _, mirobod, _ = world
    ali = Rider("Ali")
    ride = net.take_bike(ali, chilonzor, T0)
    with pytest.raises(ValueError):
        net.return_bike(ali, mirobod, T0 - timedelta(minutes=1))
    assert places_of(net, ride.bike) == 0 and ride.bike.status is BikeStatus.IN_USE


def test_a_bike_is_in_exactly_one_place_during_a_whole_ride(world):
    net, chilonzor, yunusobod, mirobod, _ = world
    ali = Rider("Ali")
    ride = net.take_bike(ali, chilonzor, T0)
    bike = ride.bike
    on_ride = lambda: sum(1 for r in net.rides if r.bike is bike and not r.is_finished)
    assert places_of(net, bike) + on_ride() == 1            # on the road
    with pytest.raises(StationFullError):
        net.return_bike(ali, yunusobod, minutes(5))
    assert places_of(net, bike) + on_ride() == 1            # failed return: still on the road
    net.return_bike(ali, mirobod, minutes(9))
    assert places_of(net, bike) + on_ride() == 1            # docked
    assert places_of(net, bike) == 1


def test_if_network_report_it_lists_stations_by_free_docks_biggest_first(world, capsys):  # optional
    net, *_ = world
    lines = net.report()
    assert [l.split(":")[0] for l in lines] == ["Mirobod", "Sergeli", "Chilonzor", "Yunusobod"]
    assert capsys.readouterr().out.splitlines() == lines


def test_if_network_has_no_station_it_is_refused():  # multiplicity 1..*
    with pytest.raises(ValueError):
        Network([])


def test_if_station_is_not_part_of_the_network_it_is_refused(world):
    net, *_ = world
    with pytest.raises(ValueError):
        net.take_bike(Rider("Ali"), stocked("Outside", 1, 1), T0)
