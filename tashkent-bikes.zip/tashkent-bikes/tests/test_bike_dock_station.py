import pytest

from bikenet import (Bike, BikeNotAvailableError, BikeNotInTransitError, BikeStatus,
                     DockOccupiedError, NoBikeError, Station)


def test_if_dock_is_free_bike_is_docked_and_status_is_available():
    station = Station("Chilonzor", 3)
    bike = Bike("B1")
    dock = station.park_bike(bike)
    assert dock.bike is bike
    assert bike.status is BikeStatus.AVAILABLE


def test_if_dock_is_occupied_dock_occupied_error_and_bike_stays_in_use():
    station = Station("Chilonzor", 1)
    station.park_bike(Bike("B1"))
    dock = station.docks[0]
    second = Bike("B2")
    with pytest.raises(DockOccupiedError):
        dock.park(second)
    assert second.status is BikeStatus.IN_USE


def test_if_outside_code_writes_dock_bike_it_fails():
    dock = Station("Chilonzor", 1).docks[0]
    with pytest.raises(AttributeError):
        dock.bike = Bike("B1")


def test_if_outside_code_writes_bike_status_it_fails():
    bike = Bike("B1")
    with pytest.raises(AttributeError):
        bike.status = BikeStatus.AVAILABLE


def test_if_outside_code_appends_to_station_docks_it_fails():
    station = Station("Chilonzor", 2)
    with pytest.raises(AttributeError):
        station.docks.append(object())
    assert station.capacity == 2


def test_if_two_stations_are_created_each_has_its_own_docks():
    a, b = Station("A", 2), Station("B", 2)
    a.park_bike(Bike("B1"))
    assert a.docks is not b.docks
    assert all(d.is_free for d in b.docks)
    assert a.docks[0] is not b.docks[0]


def test_if_bike_is_in_repair_it_stays_in_dock_but_cannot_be_taken():
    station = Station("Chilonzor", 2)
    bike = Bike("B1")
    station.park_bike(bike)
    station.send_to_repair(1)
    assert bike.status is BikeStatus.REPAIR
    assert station.docks[0].bike is bike
    assert len(station) == 1
    with pytest.raises(NoBikeError):
        station.take_bike()


def test_if_only_a_docked_free_bike_can_be_sent_to_repair():
    station = Station("Chilonzor", 2)
    with pytest.raises(BikeNotAvailableError):  # empty dock
        station.send_to_repair(1)
    station.park_bike(Bike("B1"))
    station.send_to_repair(1)
    with pytest.raises(BikeNotAvailableError):  # already in repair
        station.send_to_repair(1)


def test_if_bike_is_repaired_it_is_available_again():
    station = Station("Chilonzor", 1)
    station.park_bike(Bike("B1"))
    station.send_to_repair(1)
    station.finish_repair(1)
    assert station.take_bike().id == "B1"


def test_if_print_station_it_shows_name_and_bikes_len_counts_docked_bikes():
    station = Station("Chilonzor", 10)
    for n in range(4):
        station.park_bike(Bike(f"B{n}"))
    assert str(station) == "Chilonzor: 4/10 bikes"
    assert len(station) == 4


def test_if_repr_station_it_is_for_logs_and_differs_from_str():
    station = Station("Chilonzor", 10)
    assert repr(station) == "Station(name='Chilonzor', capacity=10, bikes=0)"
    assert repr(station) != str(station)


def test_if_sorted_stations_they_are_ordered_by_free_docks():  # optional part
    a, b, c = Station("A", 3), Station("B", 3), Station("C", 3)
    a.park_bike(Bike("1"))
    a.park_bike(Bike("2"))   # 1 free
    b.park_bike(Bike("3"))   # 2 free
    assert sorted([c, a, b]) == [a, b, c]  # 1, 2, 3 free docks


def test_if_bike_is_already_docked_it_cannot_be_parked_in_a_second_dock():
    one, two = Station("A", 1), Station("B", 1)
    bike = Bike("B1")
    one.park_bike(bike)
    with pytest.raises(BikeNotInTransitError):
        two.park_bike(bike)
    assert two.docks[0].is_free


def test_if_station_has_no_docks_it_is_refused():
    with pytest.raises(ValueError):
        Station("Empty", 0)
