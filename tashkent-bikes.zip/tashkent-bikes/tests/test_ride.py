import re
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from bikenet import Bike, ReceiptPrinter, Ride, RideNotFinishedError, Rider, Station

T0 = datetime(2026, 11, 10, 9, 0, 0)


def finished_ride(duration: timedelta, start="Chilonzor", end="Yunusobod") -> Ride:
    a, b = Station(start, 2), Station(end, 2)
    ride = Ride(Rider("Ali"), Bike("B1"), a, T0)
    ride.finish(b, T0 + duration)
    return ride


@pytest.mark.parametrize("duration, fee", [
    (timedelta(minutes=15), 0),
    (timedelta(minutes=15, seconds=1), 500),
    (timedelta(minutes=20), 500),
    (timedelta(minutes=20, seconds=1), 1_000),
    (timedelta(hours=10), 20_000),
])
def test_if_ride_lasted_x_the_fee_is_y(duration, fee):
    # 15:00 -> 0 | 15:01 -> 500 | 20:00 -> 500 | 20:01 -> 1 000 | very long -> 20 000 cap
    assert finished_ride(duration).fee() == fee


def test_if_end_time_is_before_start_time_value_error():
    ride = Ride(Rider("Ali"), Bike("B1"), Station("A", 1), T0)
    with pytest.raises(ValueError):
        ride.finish(Station("B", 1), T0 - timedelta(seconds=1))
    assert not ride.is_finished


def test_if_fee_is_asked_before_the_ride_ends_it_is_refused():
    ride = Ride(Rider("Ali"), Bike("B1"), Station("A", 1), T0)
    with pytest.raises(RideNotFinishedError):
        ride.fee()


def test_if_fee_numbers_live_outside_ride_they_must_be_moved():
    """DRY check: 500 and 20 000 are written only in ride.py."""
    package = Path(__file__).resolve().parent.parent / "bikenet"
    pattern = re.compile(r"\b(500|20_?000)\b")
    for path in package.glob("*.py"):
        if path.name == "ride.py":
            continue
        assert not pattern.search(path.read_text()), f"fee number found in {path.name}"


def test_if_receipt_printer_prints_ride_it_shows_route_minutes_and_fee(capsys):
    ReceiptPrinter().print(finished_ride(timedelta(minutes=23)))
    assert capsys.readouterr().out.strip() == "Chilonzor → Yunusobod, 23 min, 1 000 sum"
