from datetime import datetime, timedelta

from .errors import RideNotFinishedError

# The money rule lives here and nowhere else. Each number is written once.
FREE_MINUTES = 15
STEP_MINUTES = 5
PRICE_PER_STEP = 500       # sum
MAX_FEE = 20_000           # sum per ride
MAX_FAILED_RETURNS = 2     # after this many failures the error carries a redirect


class Ride:
    """An event with data: who rode which bike, where and when. Owns the fee rule."""

    def __init__(self, rider, bike, start_station, start_time: datetime):
        self._rider = rider
        self._bike = bike
        self._start_station = start_station
        self._start_time = start_time
        self._end_station = None
        self._end_time = None
        self._failed_returns = 0

    @property
    def rider(self):
        return self._rider

    @property
    def bike(self):
        return self._bike

    @property
    def start_station(self):
        return self._start_station

    @property
    def end_station(self):
        return self._end_station

    @property
    def start_time(self) -> datetime:
        return self._start_time

    @property
    def end_time(self):
        return self._end_time

    @property
    def is_finished(self) -> bool:
        return self._end_time is not None

    @property
    def failed_returns(self) -> int:
        return self._failed_returns

    def record_failed_return(self) -> int:
        """Count one failed return of this ride and give the new total."""
        self._failed_returns += 1
        return self._failed_returns

    def check_end_time(self, end_time: datetime) -> None:
        if end_time < self._start_time:
            raise ValueError("a ride cannot end before it starts")

    def finish(self, end_station, end_time: datetime) -> None:
        if self.is_finished:
            raise ValueError("this ride is already finished")
        self.check_end_time(end_time)
        self._end_station = end_station
        self._end_time = end_time

    @property
    def duration(self) -> timedelta:
        if self._end_time is None:
            raise RideNotFinishedError("the ride is still running")
        return self._end_time - self._start_time

    @property
    def duration_minutes(self) -> int:
        return int(self.duration.total_seconds() // 60)

    def fee(self) -> int:
        """Money in whole sum: first 15 min free, then 500 per started 5 min, max 20 000."""
        extra_seconds = int(self.duration.total_seconds()) - FREE_MINUTES * 60
        if extra_seconds <= 0:
            return 0
        step_seconds = STEP_MINUTES * 60
        started_steps = -(-extra_seconds // step_seconds)  # ceiling division
        return min(started_steps * PRICE_PER_STEP, MAX_FEE)

    def __repr__(self) -> str:
        return (f"Ride(bike={self._bike.id!r}, from={self._start_station.name!r}, "
                f"finished={self.is_finished})")
