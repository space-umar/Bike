from datetime import datetime

from .errors import NoActiveRideError, RideActiveError, StationFullError
from .receipt import ReceiptPrinter
from .ride import MAX_FAILED_RETURNS, Ride
from .rider import Rider
from .station import Station


class Network:
    """Runs rides: take a bike, return a bike, manager report."""

    def __init__(self, stations, printer: ReceiptPrinter = None):
        self._stations = {}
        for station in stations:
            if station.name in self._stations:
                raise ValueError(f"duplicate station name: {station.name}")
            self._stations[station.name] = station
        if not self._stations:
            raise ValueError("a network needs at least one station")
        self._printer = printer if printer is not None else ReceiptPrinter()
        self._rides = []

    @property
    def stations(self) -> tuple:
        return tuple(self._stations.values())

    @property
    def rides(self) -> tuple:
        return tuple(self._rides)

    def _require_member(self, station: Station) -> None:
        if self._stations.get(station.name) is not station:
            raise ValueError(f"{station.name} is not part of this network")

    def take_bike(self, rider: Rider, station: Station, now: datetime) -> Ride:
        self._require_member(station)
        if rider.active_ride is not None:
            raise RideActiveError(f"{rider.name} already has an active ride")
        bike = station.take_bike()  # NoBikeError if nothing to take
        ride = Ride(rider, bike, station, now)
        rider.start_ride(ride)
        self._rides.append(ride)
        return ride

    def return_bike(self, rider: Rider, station: Station, now: datetime) -> Ride:
        self._require_member(station)
        ride = rider.active_ride
        if ride is None:
            raise NoActiveRideError(f"{rider.name} has no active ride")
        ride.check_end_time(now)  # fail before the bike is moved
        try:
            station.park_bike(ride.bike)
        except StationFullError as full:
            failures = ride.record_failed_return()  # the ride keeps running
            redirect = None
            if failures >= MAX_FAILED_RETURNS:
                redirect = self._best_redirect(station)
            raise StationFullError(station.name, redirect) from full
        ride.finish(station, now)
        rider.close_ride()
        self._printer.print(ride)
        return ride

    def _best_redirect(self, full_station: Station):
        """Station with most free docks; tie -> name A-Z; None if nothing is free."""
        candidates = [s for s in self._stations.values()
                      if s is not full_station and s.free_docks > 0]
        if not candidates:
            return None
        return min(candidates, key=lambda s: (-s.free_docks, s.name))

    def send_to_repair(self, station: Station, dock_number: int) -> None:
        self._require_member(station)
        station.send_to_repair(dock_number)

    def report(self) -> list:
        """Manager view: stations by free docks, biggest first (tie -> name A-Z)."""
        ordered = sorted(self._stations.values(), key=lambda s: (-s.free_docks, s.name))
        lines = [f"{s.name}: free docks = {s.free_docks} ({len(s)}/{s.capacity} bikes)"
                 for s in ordered]
        for line in lines:
            print(line)
        return lines
