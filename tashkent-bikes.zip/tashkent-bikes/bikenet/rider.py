from __future__ import annotations

from dataclasses import dataclass, field

from .errors import NoActiveRideError, RideActiveError


@dataclass(eq=False)
class Rider:
    """A rider (the app calls them users). Mostly data, so a dataclass."""

    name: str
    _active_ride: object = field(default=None, init=False, repr=False)

    @property
    def active_ride(self):
        return self._active_ride

    def start_ride(self, ride) -> None:
        if self._active_ride is not None:
            raise RideActiveError(f"{self.name} already has an active ride")
        self._active_ride = ride

    def close_ride(self):
        if self._active_ride is None:
            raise NoActiveRideError(f"{self.name} has no active ride")
        ride, self._active_ride = self._active_ride, None
        return ride
