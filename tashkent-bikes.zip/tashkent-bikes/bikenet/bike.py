from enum import Enum

from .errors import BikeNotAvailableError, BikeNotInTransitError


class BikeStatus(Enum):
    AVAILABLE = "AVAILABLE"  # docked, can be taken
    IN_USE = "IN_USE"        # not in any dock (on a ride, or not placed yet)
    REPAIR = "REPAIR"        # docked, nobody can take it


class Bike:
    """A bike. Only the bike itself changes its status."""

    def __init__(self, bike_id: str):
        self._id = bike_id
        self._status = BikeStatus.IN_USE  # a new bike is outside every dock

    @property
    def id(self) -> str:
        return self._id

    @property
    def status(self) -> BikeStatus:
        return self._status

    def mark_docked(self) -> None:
        if self._status is not BikeStatus.IN_USE:
            raise BikeNotInTransitError(f"{self._id} is already docked")
        self._status = BikeStatus.AVAILABLE

    def mark_taken(self) -> None:
        if self._status is not BikeStatus.AVAILABLE:
            raise BikeNotAvailableError(f"{self._id} is {self._status.value}")
        self._status = BikeStatus.IN_USE

    def mark_repair(self) -> None:
        if self._status is not BikeStatus.AVAILABLE:
            raise BikeNotAvailableError(f"{self._id} is {self._status.value}")
        self._status = BikeStatus.REPAIR

    def mark_repaired(self) -> None:
        if self._status is not BikeStatus.REPAIR:
            raise BikeNotAvailableError(f"{self._id} is not in repair")
        self._status = BikeStatus.AVAILABLE

    def __repr__(self) -> str:
        return f"Bike(id={self._id!r}, status={self._status.name})"
