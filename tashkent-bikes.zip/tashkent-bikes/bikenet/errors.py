"""Every domain error of the bike network, in one place."""


class BikeNetError(Exception):
    """Base class for all errors raised by the bike network."""


class DockOccupiedError(BikeNetError):
    """A bike was parked into a dock that already holds a bike."""


class BikeNotInTransitError(BikeNetError):
    """A bike that is already docked (or in repair) was parked again."""


class BikeNotAvailableError(BikeNetError):
    """The bike is not AVAILABLE, so the requested change is not allowed."""


class NoBikeError(BikeNetError):
    """The station has no free (AVAILABLE) bike to take."""


class RideActiveError(BikeNetError):
    """The rider already has an active ride."""


class NoActiveRideError(BikeNetError):
    """The rider tried to return a bike without an active ride."""


class RideNotFinishedError(BikeNetError):
    """The fee was asked for a ride that is still running."""


class StationFullError(BikeNetError):
    """The station has no free dock.

    `redirect` is None, or the station with the most free docks
    (set after the same ride failed MAX_FAILED_RETURNS times).
    """

    def __init__(self, station_name, redirect=None):
        self.station_name = station_name
        self.redirect = redirect
        message = f"{station_name} is full"
        if redirect is not None:
            message += f"; try {redirect.name} ({redirect.free_docks} free docks)"
        super().__init__(message)
