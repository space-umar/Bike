from .bike import Bike
from .dock import Dock
from .errors import NoBikeError, StationFullError


class Station:
    """A station owns its docks (created inside, so no shared class attribute)."""

    def __init__(self, name: str, capacity: int):
        if capacity < 1:
            raise ValueError("a station needs at least 1 dock")
        self._name = name
        self._docks = tuple(Dock(n) for n in range(1, capacity + 1))

    @property
    def name(self) -> str:
        return self._name

    @property
    def docks(self) -> tuple:
        return tuple(self._docks)  # a tuple copy: .append() is impossible

    @property
    def capacity(self) -> int:
        return len(self._docks)

    @property
    def free_docks(self) -> int:
        return sum(1 for d in self._docks if d.is_free)

    def park_bike(self, bike: Bike) -> Dock:
        for dock in self._docks:
            if dock.is_free:
                dock.park(bike)
                return dock
        raise StationFullError(self._name)

    def take_bike(self) -> Bike:
        for dock in self._docks:
            if dock.has_available_bike:
                return dock.take()
        raise NoBikeError(f"{self._name} has no available bike")

    def send_to_repair(self, dock_number: int) -> None:
        self._docks[dock_number - 1].send_to_repair()

    def finish_repair(self, dock_number: int) -> None:
        self._docks[dock_number - 1].finish_repair()

    def __len__(self) -> int:
        return sum(1 for d in self._docks if not d.is_free)

    def __str__(self) -> str:
        return f"{self._name}: {len(self)}/{self.capacity} bikes"

    def __repr__(self) -> str:
        return f"Station(name={self._name!r}, capacity={self.capacity}, bikes={len(self)})"

    def __lt__(self, other: "Station") -> bool:
        return self.free_docks < other.free_docks
