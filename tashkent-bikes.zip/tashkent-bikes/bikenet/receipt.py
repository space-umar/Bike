from .ride import Ride


class ReceiptPrinter:
    """Console receipt for a finished ride."""

    def format(self, ride: Ride) -> str:
        fee = f"{ride.fee():,}".replace(",", " ")
        return (f"{ride.start_station.name} → {ride.end_station.name}, "
                f"{ride.duration_minutes} min, {fee} sum")

    def print(self, ride: Ride) -> None:
        print(self.format(ride))
