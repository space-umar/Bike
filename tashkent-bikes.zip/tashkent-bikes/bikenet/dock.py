from .bike import Bike, BikeStatus
from .errors import BikeNotAvailableError, DockOccupiedError, NoBikeError


class Dock:
    """One place for at most one bike."""

    def __init__(self, number: int):
        self._number = number
        self._bike = None

    @property
    def number(self) -> int:
        return self._number

    @property
    def bike(self):
        return self._bike

    @property
    def is_free(self) -> bool:
        return self._bike is None

    @property
    def has_available_bike(self) -> bool:
        return self._bike is not None and self._bike.status is BikeStatus.AVAILABLE

    def park(self, bike: Bike) -> None:
        if self._bike is not None:
            raise DockOccupiedError(f"dock {self._number} is occupied")
        bike.mark_docked()  # raises if the bike is already somewhere else
        self._bike = bike

    def take(self) -> Bike:
        if not self.has_available_bike:
            raise NoBikeError(f"dock {self._number} has no available bike")
        bike = self._bike
        bike.mark_taken()
        self._bike = None
        return bike

    def send_to_repair(self) -> None:
        if not self.has_available_bike:
            raise BikeNotAvailableError(
                f"dock {self._number}: only a docked free bike can be sent to repair"
            )
        self._bike.mark_repair()

    def finish_repair(self) -> None:
        if self._bike is None:
            raise BikeNotAvailableError(f"dock {self._number} is empty")
        self._bike.mark_repaired()

    def __repr__(self) -> str:
        return f"Dock(number={self._number}, bike={self._bike!r})"
