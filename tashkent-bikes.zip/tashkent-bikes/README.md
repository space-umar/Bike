# Tashkent Bike Network

Console model of a bike-sharing network: stations with docks, bikes, riders, rides with a fee rule,
failure/recovery when a station is full, and a manager report. Pure Python 3.10+, no files, no database, no threads.

```
bikenet/            the code (bike, dock, station, ride, rider, network, receipt, errors)
tests/              pytest; every test name is the "If" line it proves
docs/design.md      noun sorting, CRC cards, scenario walk-through (paper design)
demo.py             the scenario shown in the video
```

## Run

```bash
python -m pytest -v     # 40 tests
python demo.py          # the demo scenario
```

---

## Demo video (max 40 seconds)

<details>
<summary>▶ Click to expand / collapse the demo video</summary>

<!-- REPLACE the line below with your own upload: drag demo.mp4 into the GitHub README editor and paste the generated
     https://github.com/user-attachments/assets/... URL on its own line. -->
https://github.com/user-attachments/assets/REPLACE-WITH-YOUR-VIDEO-ID

**Exact scenario, step by step** (`python demo.py`, then `python -m pytest -v` at the end):

| Time | Step | What you see |
|---|---|---|
| 0–5 s | Start: manager view | `network.report()`: stations ordered by free docks |
| 5–13 s | **1. Happy path.** Ali takes a bike at Chilonzor, returns it to a free dock at Yunusobod after 23 min | receipt `Chilonzor → Yunusobod, 23 min, 1 000 sum` |
| 13–23 s | **2. Failure path.** Vali takes a bike and returns it to the now full Yunusobod. Attempt 1 fails, attempt 2 fails (n = 2 used up) | `Yunusobod is full` then `Yunusobod is full; try Mirobod (3 free docks)`; ride still running |
| 23–29 s | **3. Recovery path.** Vali returns to the redirected station Mirobod | ride closed, fee charged, receipt `Chilonzor → Mirobod, 21 min, 1 000 sum` |
| 29–33 s | **4. Optional part.** A bike goes to repair and stays in its dock; manager report again | `Chilonzor: 2/4 bikes`, report sorted biggest first |
| 33–40 s | `python -m pytest -v` | 40 passed |

Output of `python demo.py`:

```text
=== START: manager view ===
Mirobod: free docks = 3 (1/4 bikes)
Sergeli: free docks = 3 (0/3 bikes)
Yunusobod: free docks = 1 (1/2 bikes)
Chilonzor: free docks = 0 (4/4 bikes)

=== 1. HAPPY PATH: Ali takes a bike and returns it to a free dock ===
Ali took a bike at Chilonzor: 3/4 bikes
Chilonzor → Yunusobod, 23 min, 1 000 sum
Yunusobod is now: Yunusobod: 2/2 bikes

=== 2. FAILURE PATH: Vali returns to the full Yunusobod, twice ===
attempt 1: Yunusobod is full
attempt 2: Yunusobod is full; try Mirobod (3 free docks)
Ride still running: Ride(bike='C-2', from='Chilonzor', finished=False)

=== 3. RECOVERY PATH: Vali returns to the redirected station ===
Chilonzor → Mirobod, 21 min, 1 000 sum

=== 4. OPTIONAL: repair and manager report ===
Chilonzor dock 3 bike sent to repair, it stays in the dock:
  Chilonzor: 2/4 bikes
Sergeli: free docks = 3 (0/3 bikes)
Chilonzor: free docks = 2 (2/4 bikes)
Mirobod: free docks = 2 (2/4 bikes)
Yunusobod: free docks = 0 (2/2 bikes)
```

</details>

### Demo per assignment item

Each item has its own tests; the test name is the "If" line it proves.

<details>
<summary>Item 1: Class discovery (docs/design.md)</summary>

Paper only. Open [`docs/design.md`](docs/design.md): noun sorting, vague-word questions, CRC cards
(`Class | Responsibilities | Collaborators`), and the "rider returns bike to a full station" walk-through with the owner of every step.

</details>

<details>
<summary>Item 2: Bike, Dock and Station protect their own rules</summary>

```bash
python -m pytest tests/test_bike_dock_station.py -v
```

1. Park a bike into a free dock: it is docked, status `AVAILABLE`.
2. Park into an occupied dock: `DockOccupiedError`, the bike stays `IN_USE`.
3. `dock.bike = x`, `bike.status = ...`, `station.docks.append(...)`: all fail.
4. Two stations: each has its own docks.
5. Bike in `REPAIR`: stays in the dock, cannot be taken; only a docked free bike can be sent to repair.
6. `print(station)` → `Chilonzor: 4/10 bikes`; `len(station)` = docked bikes; `repr` is for logs.
7. Optional: `sorted(stations)` orders by free docks.

</details>

<details>
<summary>Item 3: Ride owns the fee rule</summary>

```bash
python -m pytest tests/test_ride.py -v
```

| Ride length | Fee |
|---|---|
| 15:00 | 0 sum |
| 15:01 | 500 sum |
| 20:00 | 500 sum |
| 20:01 | 1 000 sum |
| very long | 20 000 sum (cap) |

End before start → `ValueError`. The numbers 15, 5, 500, 20 000 are constants in `bikenet/ride.py` only (a test scans the other files).
`ReceiptPrinter.print(ride)` → `Chilonzor → Yunusobod, 23 min, 1 000 sum`.

</details>

<details>
<summary>Item 4: Network runs the ride (take / return)</summary>

```bash
python -m pytest tests/test_network.py -v
```

Happy, failure (n = 2 then redirect, tie → name A–Z) and recovery paths are in the main video above.
Also tested: `RideActiveError`, `NoBikeError`, `NoActiveRideError`, return time before start, and the optional `network.report()`.

</details>

<details>
<summary>Item 5: Relationships table (below)</summary>

See the next section. Every row has a `file:line`; `python -m pytest -v` still passes with the code that those lines point to.

</details>

---

## Relationships table

Lines refer to the code in this repository (checked after the last code change).

| # | Pair | Relationship | Multiplicity (A – B) | Proof (file:line) |
|---|---|---|---|---|
| 1 | Network – Station | **aggregation** (stations are created outside and handed in) | 1 – 1..* | `bikenet/network.py:18` stores the given station |
| 2 | Station – Dock | **composition** (docks are created inside `Station`) | 1 – 1..* | `bikenet/station.py:13` creates the docks |
| 3 | Dock – Bike | **aggregation** (bike comes from outside and lives on) | 1 – 0..1 | `bikenet/dock.py:32` stores the given bike |
| 4 | Network – Ride | **composition** (rides are created inside `Network`) | 1 – 0..* | `bikenet/network.py:41` creates, `:43` keeps the ride |
| 5 | Rider – Ride (active) | **association** (keeps a link to an independent ride) | 1 – 0..1 | `bikenet/rider.py:22` |
| 6 | Ride – Rider | **association** | * – 1 | `bikenet/ride.py:17` |
| 7 | Ride – Bike | **association** | * – 1 | `bikenet/ride.py:18` |
| 8 | Ride – Station (start) | **association** | * – 1 | `bikenet/ride.py:19` |
| 9 | Ride – Station (end) | **association** | * – 0..1 (empty until the ride ends) | `bikenet/ride.py:70` |
| 10 | Network – ReceiptPrinter | **association** (injected, default created if none) | 1 – 1 | `bikenet/network.py:21` |
| 11 | ReceiptPrinter – Ride | **dependency** (only a parameter) | – | `bikenet/receipt.py:7` |
| 12 | Network – Rider | **dependency** (only a parameter) | – | `bikenet/network.py:36` |

### Lifetime tests (aggregation and composition)

| Row | Question | Answer |
|---|---|---|
| 1 Network ◇ Station | If I delete the Network, do its Stations disappear? | **No.** The caller still holds them (`demo.py` variables). → aggregation |
| 2 Station ◆ Dock | If I delete the Station, do its Docks disappear? | **Yes.** Nobody else has a reference; they were created inside it. → composition |
| 3 Dock ◇ Bike | If I delete the Dock, does the Bike disappear? | **No.** The bike is owned by the caller / the ride and can be parked elsewhere. → aggregation |
| 4 Network ◆ Ride | If I delete the Network, do its Rides disappear? | **Yes.** The ride history is kept only inside `Network._rides` (a rider may still point to an active ride, but the history record is gone). → composition |

### Multiplicities: enforced or explained

| Multiplicity | Enforced by | Test |
|---|---|---|
| Station has 1..* docks | `bikenet/station.py:10` (capacity < 1 → `ValueError`) | `test_if_station_has_no_docks_it_is_refused` |
| Dock holds 0..1 bike | `bikenet/dock.py:29-30` (`DockOccupiedError`) | `test_if_dock_is_occupied_dock_occupied_error_and_bike_stays_in_use` |
| Rider has 0..1 active ride | `bikenet/rider.py:20-21` (`RideActiveError`) | `test_if_rider_already_has_an_active_ride_ride_active_error` |
| Bike is in 0..1 dock | `bikenet/bike.py:28-29` (`BikeNotInTransitError`) | `test_if_bike_is_already_docked_it_cannot_be_parked_in_a_second_dock` |
| **Network has 1..* stations** | **found not enforced, now fixed:** `bikenet/network.py:19-20` (`ValueError`) | `test_if_network_has_no_station_it_is_refused` |
| A Station belongs to 1 Network | **not enforced, and fine:** nothing stops the same `Station` object from being passed to two `Network` objects. This console app runs exactly one network per process, so a second owner never exists. If several networks were needed, `Station` would get an owner field. | – |

---

## "A bike is in exactly one place"

```text
RULE: at any moment a bike is in exactly ONE place: in one dock, or on one active ride.

My own explanation of how the repo keeps this true:

1. The bike's status is the marker of "where it is".
   AVAILABLE and REPAIR mean "inside a dock". IN_USE means "outside every dock"
   (on a ride; a brand-new bike also starts IN_USE because it is not placed yet).

2. Only a Dock moves a bike, and every move goes through the bike's own status check:

       # dock.py:28-32  Dock.park(bike)
       if self._bike is not None:            raise DockOccupiedError   # one bike per dock
       bike.mark_docked()                    # bike.py:28-29: allowed only from IN_USE
       self._bike = bike

   A bike that is already docked is not IN_USE, so a second Dock refuses it
   (BikeNotInTransitError). Nothing is changed when a check fails, because the
   checks run before the assignment.

3. Taking is the mirror move: Dock.take() calls bike.mark_taken() (AVAILABLE -> IN_USE)
   and only then empties the dock. A REPAIR bike is not AVAILABLE, so nobody can take it,
   but it stays in its dock: still one place.

4. A Ride holds the bike only between "take" and "return". Network.return_bike() parks the
   bike FIRST (network.py:53) and finishes the ride only after that succeeded. If the station
   is full, parking raises, nothing moved, the bike is still on the ride (one place), and the
   ride clock keeps running.

5. Outside code cannot break it: dock.bike and bike.status are read-only properties
   and station.docks returns a tuple copy.

Proof: tests/test_network.py::test_a_bike_is_in_exactly_one_place_during_a_whole_ride
       counts docks + unfinished rides holding the bike after take, after a failed return,
       and after a successful return. The sum is 1 every time.
```
